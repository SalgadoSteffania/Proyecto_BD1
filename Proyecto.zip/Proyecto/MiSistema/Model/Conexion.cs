﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiSistema.Model
{
    class Conexion
    {   //VPN: IPMáquina 

        //public static string Cn = "Data Source=WALGER-PC; Initial Catalog=neptuno; Integrated Security=true";
        public static string Cn = "Data Source=LAPTOP-4F37L5PP; Initial Catalog=NuevoHotel; user=uni; password =sistemas123";
    }
}
