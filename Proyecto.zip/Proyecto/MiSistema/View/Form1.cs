﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MiSistema.View;

namespace MiSistema
{
    public partial class Form1 : Form
    {
        string rol;

        public string Rol { get => rol; set => rol = value; }

        public Form1()
        {
            InitializeComponent();
        }
        public Form1(string rol)
        {
            InitializeComponent();
            this.rol = rol;
        }


        private void clienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCliente fc = new frmCliente();
            fc.MdiParent = this;
            fc.Show();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
         //   this.txtRol.Text = frmInicio.Rol;
            if(rol == "Administrador")
            {
               // this.catálogosToolStripMenuItem.Enabled = false;
               // this.reportesToolStripMenuItem.Enabled = false;
               //this.reservasToolStripMenuItem.Enabled = false;
               // this.cancelacionesToolStripMenuItem.Enabled = false;
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void usuarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUsuario fc = new frmUsuario();
            fc.MdiParent = this;
            fc.Show();
        }

        private void facturaciónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmFactura fc = new frmFactura();
            fc.MdiParent = this;
            fc.Show();
        }
    }
}
