﻿namespace CapaPresenta
{


    partial class dtsPrincipal
    {
    }
}
