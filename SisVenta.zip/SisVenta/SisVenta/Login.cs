﻿using CapaDato;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SisVenta
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        int cont = 3;

  


        private void btnIngresar_Click(object sender, EventArgs e)
        {
            DataTable Datos = CapaNeg.NTrabajador.Login(this.txtUsuario.Text, this.txtClave.Text);


            //if (Datos.Rows.Count == 0)
            //{
            //    MessageBox.Show("NO Tiene Acceso al Sistema", "Sistema de Ventas", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
            //else
            //{
            //    Login fr = new Login();
            //    this.Hide();
            //    Welcome w = new Welcome();
            //    w.ShowDialog();

            //    Principal frm = new Principal();
            //    frm.Idtrabajador = Datos.Rows[0][0].ToString();
            //    frm.Apellidos = Datos.Rows[0][1].ToString();
            //    frm.Nombre = Datos.Rows[0][2].ToString();
            //    frm.Acceso = Datos.Rows[0][3].ToString();
            //    frm.Show();

            //}
            //Cursor.Current = Cursors.Default;
            //--cont;
            //MessageBox.Show("Error: Usuario o contraseña incorrecta ", cont + " Intentos restantes");

            //if (cont == 0)
            //{
            //    cont = 3;
            //    btnIngresar.Enabled = false;
            //    //button1.Enabled = false;
            //    btnSalir.Enabled = false;
            //    MessageBox.Show("3 Intentos fallidos , espere un momento para intentar nuevamente");
            //    Thread.Sleep(300000);
            //    btnIngresar.Enabled = true;
            //    btnSalir.Enabled = true;
            //}



            if (Datos.Rows.Count == 0)
            {
                MessageBox.Show("NO Tiene Acceso al Sistema", "Sistema de Ventas", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Cursor.Current = Cursors.Default;
                --cont;
                MessageBox.Show("Error: Usuario o contraseña incorrecta ", cont + " Intentos restantes");

                if (cont == 0)
                {
                    cont = 3;
                    btnIngresar.Enabled = false;
                    //button1.Enabled = false;
                    btnSalir.Enabled = false;
                    MessageBox.Show("3 Intentos fallidos , espere un momento para intentar nuevamente");
                    Thread.Sleep(3000);
                    btnIngresar.Enabled = true;
                    btnSalir.Enabled = true;
                }

            }
            else
            {

                Login fr = new Login();
                this.Hide();
                Welcome w = new Welcome();
                w.ShowDialog();

                Principal frm = new Principal();
                frm.Idtrabajador = Datos.Rows[0][0].ToString();
                frm.Apellidos = Datos.Rows[0][1].ToString();
                frm.Nombre = Datos.Rows[0][2].ToString();
                frm.Acceso = Datos.Rows[0][3].ToString();
                frm.Show();


            }




        }



        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }











    }
}
